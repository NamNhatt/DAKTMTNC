package com.example.blesample;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ChildActivity extends AppCompatActivity {

    private BroadcastReceiver receiver;
    private LineChart lineChart;
    private List<Entry> entries1, entries2;  // Nhịp tim và SpO2
    private List<String> xValues;  // Danh sách thời gian cho trục X
    private XAxis xAxis;
    private Handler handler;
    private TextView nhiptim, spo2, ketqua;
    private long initialTimestamp = -1;  // Lưu timestamp ban đầu
    private long lastTimestamp= -1 ;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child);

        lineChart = findViewById(R.id.chart);
        nhiptim = findViewById(R.id.nhiptim);
        spo2 = findViewById(R.id.spo2);
        ketqua = findViewById(R.id.ketqua);

        lineChart.getXAxis().setTextColor(Color.WHITE);
        lineChart.getAxisLeft().setTextColor(Color.WHITE);
        lineChart.getAxisRight().setTextColor(Color.WHITE);
        lineChart.getLegend().setTextColor(Color.WHITE);
        lineChart.getDescription().setTextColor(Color.WHITE);

        // Thiết lập biểu đồ
        Description description = new Description();
        description.setText("Thời gian (giây)");
        description.setTextColor(Color.WHITE);
        lineChart.setDescription(description);
        setupChart();

        // Khởi tạo danh sách dữ liệu
        entries1 = new ArrayList<>();
        entries2 = new ArrayList<>();
        xValues = new ArrayList<>();  // Khởi tạo danh sách thời gian

        // Thiết lập Handler để lấy dữ liệu mỗi giây
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                readLogData();
                handler.postDelayed(this, 1000);  // Lặp lại mỗi giây
            }
        }, 1000);

        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String heart_rate_value = intent.getStringExtra("heart_rate");
                String spo2_value = intent.getStringExtra("spo2");

                if (heart_rate_value != null) {
                    nhiptim.setText("Heart rate: " + heart_rate_value.split(",")[1] +"\n" +"Date: "+heart_rate_value.split(",")[0]);
                }
                if (spo2_value != null) {
                    spo2.setText("Spo2: " + spo2_value.split(",")[1]+"\n"+ "Date: "+spo2_value.split(",")[0]);
                }
            }
        };

        IntentFilter filter = new IntentFilter("DATA_UPDATE");
        registerReceiver(receiver, filter);
    }

    private void setupChart() {
        xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setLabelCount(10);
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xValues)); // Không cần granularity

        YAxis yAxis1 = lineChart.getAxisLeft();
        yAxis1.setAxisMinimum(50f);
        yAxis1.setAxisMaximum(150f);
        yAxis1.setAxisLineWidth(2f);
        yAxis1.setAxisLineColor(Color.RED);

        YAxis yAxis2 = lineChart.getAxisRight();
        yAxis2.setAxisMinimum(0f);
        yAxis2.setAxisMaximum(100f);
        yAxis2.setAxisLineWidth(2f);
        yAxis2.setAxisLineColor(Color.BLUE);
    }

    private void readLogData() {
        File logFile = new File(getExternalFilesDir(null), "ble_log.txt");

        if (!logFile.exists()) {
            return;  // Tệp không tồn tại
        }

        try (FileInputStream fis = new FileInputStream(logFile);
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader br = new BufferedReader(isr)) {

            String line;

            xValues.clear();
            entries1.clear();
            entries2.clear();
            initialTimestamp = -1;  // Reset timestamp ban đầu mỗi lần đọc lại file
            lastTimestamp = -1;

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");  // Phân tích dữ liệu từ tệp
                if (data.length == 3) {
                    String timeStr = data[0];  // Thời gian ở vị trí thứ 1
                    String uuid = data[2];  // UUID ở vị trí thứ 2
                    if(uuid.equals("heart_rate")==false && uuid.equals("spo2")==false)
                        continue;
                    float value = Float.parseFloat(data[1]);  // Giá trị ở vị trí thứ 3

                    // Chuyển đổi thời gian sang timestamp (giây)
                    long timestamp = convertTimeToSeconds(timeStr);

                    // Thiết lập timestamp ban đầu
                    if (initialTimestamp == -1) {
                        initialTimestamp = timestamp;
                    }

                    // Tính khoảng thời gian tính từ thời điểm ban đầu
                    float timeDiff = (timestamp - initialTimestamp);

                    lastTimestamp = timestamp;

                    // Thêm dữ liệu nhịp tim hoặc SpO2
                    if (uuid.equals("heart_rate")) {
                        entries1.add(new Entry(timeDiff, value));  // Thêm dữ liệu nhịp tim
                    } else if (uuid.equals("spo2")) {
                        entries2.add(new Entry(timeDiff, spo2convert(value)));  // Thêm dữ liệu SpO2
                    }
                }
            }

            for (long i = 0; i <= (lastTimestamp-initialTimestamp);i++) {
                if (i%15==0){
                    long sum = initialTimestamp + i;
                    String date = convertTimestampToDateTime(sum);
                    date = convertTimeToLabel(date);
                    xValues.add(date);
                } else {
                    xValues.add("");
                }

            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        // Cập nhật biểu đồ
        updateChart();
    }

    private float spo2convert(float value) {
        return value + 50;
    }

    private long convertTimeToSeconds(String timeStr) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = inputFormat.parse(timeStr);
            return date.getTime() / 1000;  // Trả về thời gian dưới dạng giây
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private String convertTimeToLabel(String timeStr) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = inputFormat.parse(timeStr);
            SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm:ss");
            return outputFormat.format(date);  // Trả về thời gian theo định dạng HH:mm:ss
        } catch (ParseException e) {
            e.printStackTrace();
            return timeStr;  // Trả về chuỗi gốc nếu có lỗi
        }
    }

    private String convertTimestampToDateTime(long timestamp) {
        // Chuyển đổi từ giây sang mili giây vì Date sử dụng mili giây
        Date date = new Date(timestamp * 1000);  // Chuyển timestamp (giây) thành mili giây
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  // Định dạng ngày giờ
        return sdf.format(date);  // Trả về chuỗi ngày giờ
    }

    private void updateChart() {
        // Cập nhật trục X chỉ hiển thị nhãn tại các điểm có dữ liệu
        xAxis.setValueFormatter(new IndexAxisValueFormatter(xValues));

        LineDataSet dataSet1 = new LineDataSet(entries1, "Nhịp tim");
        dataSet1.setColor(Color.RED);
        dataSet1.setLineWidth(2f);
        dataSet1.setDrawValues(false);

        LineDataSet dataSet2 = new LineDataSet(entries2, "SpO2");
        dataSet2.setColor(Color.BLUE);
        dataSet2.setLineWidth(2f);
        dataSet2.setDrawValues(false);

        LineData lineData = new LineData(dataSet1, dataSet2);
        lineChart.setData(lineData);
        lineChart.invalidate();  // Cập nhật biểu đồ
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);  // Dừng handler khi Activity bị hủy
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(ChildActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT); // Đưa MainActivity lên đầu stack
        startActivity(intent);
    }


}
