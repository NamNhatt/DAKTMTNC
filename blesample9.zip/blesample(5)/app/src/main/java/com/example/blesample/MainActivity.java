package com.example.blesample;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    BluetoothManager btManager;
    BluetoothAdapter btAdapter;
    BluetoothLeScanner btScanner;
    Button startScanningButton;
    Button stopScanningButton;
    TextView peripheralTextView;
    private final static int REQUEST_ENABLE_BT = 1;

    Button chuyen;
    TextView status_view;
    String value;
    String pre_lastValue="null";
    String pre_secondLastValue="null";

    Boolean btScanning = false;
    Boolean senddata = false;
    Boolean running = false;
    int deviceIndex = 0;
    ArrayList<BluetoothDevice> devicesDiscovered = new ArrayList<>();
    Button disconnectDevice;
    BluetoothGatt bluetoothGatt;

    private List<UUID> characteristicUUIDs = new ArrayList<>();
    private UUID serviceUUID;

    private Handler mHandler = new Handler();
    private static final long SCAN_PERIOD = 5000;

    private static final String CLIENT_CHARACTERISTIC_CONFIG = "00002902-0000-1000-8000-00805f9b34fb";

    private Handler readHandler = new Handler();
    private Runnable readRunnable;
    private boolean isReading = false;
    private UUID lastUUID ;
    private UUID secondLastUUID  ;
    private UUID thirdLastUUID  ;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chuyen = findViewById(R.id.chuyen);
        chuyen.setOnClickListener(view -> {
            Intent myintent = new Intent(MainActivity.this, ChildActivity.class);
            myintent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT); // Đưa ChildActivity lên đầu stack nếu đã tồn tại
            startActivity(myintent);
        });

        status_view = findViewById(R.id.status);
        peripheralTextView = findViewById(R.id.PeripheralTextView);
        peripheralTextView.setMovementMethod(new ScrollingMovementMethod());

        disconnectDevice = findViewById(R.id.DisconnectButton);
        disconnectDevice.setVisibility(View.INVISIBLE);
        disconnectDevice.setOnClickListener(v -> disconnectDeviceSelected());

        startScanningButton = findViewById(R.id.StartScanButton);
        startScanningButton.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("This app needs location access");
                builder.setMessage("Please grant location access so this app can detect peripherals.");
                builder.setPositiveButton(android.R.string.ok, (dialog, which) -> openAppSettings());
                builder.show();
            } else {
                startScanning();
            }
        });

        stopScanningButton = findViewById(R.id.StopScanButton);
        stopScanningButton.setOnClickListener(v -> stopScanning());
        stopScanningButton.setVisibility(View.INVISIBLE);

        btManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        btAdapter = btManager.getAdapter();
        btScanner = btAdapter.getBluetoothLeScanner();

        if (btAdapter != null && !btAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        }
        loadLastValuesFromLog();
    }

    @SuppressLint("NewApi")
    private ScanCallback leScanCallback = new ScanCallback() {
        @SuppressLint("MissingPermission")
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice device = result.getDevice();

            // Kiểm tra xem thiết bị đã tồn tại trong danh sách hay chưa
            boolean alreadyDiscovered = false;
            for (BluetoothDevice discoveredDevice : devicesDiscovered) {
                if (discoveredDevice.getAddress().equals(device.getAddress())) {
                    alreadyDiscovered = true;
                    break;
                }
            }

            // Nếu thiết bị chưa được phát hiện, thêm vào danh sách
            if (!alreadyDiscovered) {
                peripheralTextView.append("Index: " + deviceIndex + ", Device Name: " + device.getName() + " rssi: " + result.getRssi() + "\n");
                devicesDiscovered.add(device);
                deviceIndex++;

                final int scrollAmount = peripheralTextView.getLayout().getLineTop(peripheralTextView.getLineCount()) - peripheralTextView.getHeight();
                if (scrollAmount > 0) {
                    peripheralTextView.scrollTo(0, scrollAmount);
                }

                if ("ESP32".equals(device.getName())) {
                    stopScanning(); // Dừng quét
                    peripheralTextView.append("ESP32 found! Stopping scan and connecting...\n");
                    bluetoothGatt = device.connectGatt(MainActivity.this, true, btleGattCallback);
                    peripheralTextView.append("Connecting to ESP32...\n");
                }
            }
        }
    };

    @SuppressLint("NewApi")
    private final BluetoothGattCallback btleGattCallback = new BluetoothGattCallback() {

        @SuppressLint("MissingPermission")
        @Override
        public void onConnectionStateChange(final BluetoothGatt gatt, final int status, final int newState) {
            switch (newState) {
                case BluetoothGatt.STATE_DISCONNECTED:
                    MainActivity.this.runOnUiThread(() -> {
                        peripheralTextView.append("device disconnected\n");
                        status_view.setText("SCAN YOUR DEVICE");
                        disconnectDevice.setVisibility(View.INVISIBLE);
                        stopReadingData();
                        running = false;
                    });
                    break;
                case BluetoothGatt.STATE_CONNECTED:
                    MainActivity.this.runOnUiThread(() -> {
                        peripheralTextView.append("device connected\n");
                        status_view.setText("DEVICE CONNECTED");
                        disconnectDevice.setVisibility(View.VISIBLE);
                    });
                    bluetoothGatt.discoverServices();
                    break;
                default:
                    MainActivity.this.runOnUiThread(() -> peripheralTextView.append("we encountered an unknown state, uh oh\n"));
                    break;
            }
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onServicesDiscovered(final BluetoothGatt gatt, final int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                MainActivity.this.runOnUiThread(() -> {
                    peripheralTextView.append("device services have been discovered\n");
                    startReadingData();
                });

                characteristicUUIDs.clear(); // Xóa danh sách trước khi thêm mới

                for (BluetoothGattService service : bluetoothGatt.getServices()) {
                    List<BluetoothGattCharacteristic> characteristics = service.getCharacteristics();
                    for (BluetoothGattCharacteristic characteristic : characteristics) {
                        if ((characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
                            serviceUUID = service.getUuid();
                            characteristicUUIDs.add(characteristic.getUuid()); // Lưu UUID
                            bluetoothGatt.readCharacteristic(characteristic);
                        }
                        if ((characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
                            bluetoothGatt.setCharacteristicNotification(characteristic, true);
                            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(UUID.fromString(CLIENT_CHARACTERISTIC_CONFIG));
                            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                            bluetoothGatt.writeDescriptor(descriptor);
                        }
                    }
                }

                if (characteristicUUIDs.size() >= 3) {
                    lastUUID = characteristicUUIDs.get(characteristicUUIDs.size() - 1);
                    secondLastUUID = characteristicUUIDs.get(characteristicUUIDs.size() - 2);
                    thirdLastUUID = characteristicUUIDs.get(characteristicUUIDs.size() - 3);
                }
            }
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                byte[] data = characteristic.getValue();
                value = new String(data);
                MainActivity.this.runOnUiThread(() -> peripheralTextView.append("(Read)Received data: " + value + "\n"));
                if(senddata == false) {
                    sendDateTimeToDevice();
                    senddata = true;
                }
                Intent intent = new Intent("DATA_UPDATE");
                if (characteristic.getUuid().equals(secondLastUUID) && value.equals(pre_secondLastValue)==false) {
                    intent.putExtra("heart_rate", value);
                    writeLog(value,"heart_rate");
                    pre_secondLastValue = value;
                } else if (characteristic.getUuid().equals(lastUUID) && value.equals(pre_lastValue)==false) {
                    intent.putExtra("spo2", value);
                    writeLog(value,"spo2");
                    pre_lastValue = value;
                }
                sendBroadcast(intent);

                BluetoothGattService service = bluetoothGatt.getService(serviceUUID);
                characteristic = service.getCharacteristic(lastUUID);
                if (service != null && running == true) {
                    characteristic = service.getCharacteristic(lastUUID);
                    if (characteristic != null) {
                        bluetoothGatt.readCharacteristic(characteristic);
                        running = false;
                    }
                }
            }
        }
        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                runOnUiThread(() -> peripheralTextView.append("Data sent successfully: " + new String(characteristic.getValue()) + "\n"));
            } else {
                runOnUiThread(() -> peripheralTextView.append("Failed to send data\n"));
            }
        }
    };

    @SuppressLint({"MissingPermission", "NewApi"})
    public void disconnectDeviceSelected() {
        peripheralTextView.append("Disconnecting from device\n");
        bluetoothGatt.disconnect();
    }

    @SuppressLint({"MissingPermission", "NewApi"})
    public void startScanning() {
        status_view.setText("SCANNING");
        btScanning = true;
        deviceIndex = 0;
        devicesDiscovered.clear();
        peripheralTextView.setText("");
        peripheralTextView.append("Started Scanning\n");
        startScanningButton.setVisibility(View.INVISIBLE);
        stopScanningButton.setVisibility(View.VISIBLE);
        AsyncTask.execute(() -> btScanner.startScan(leScanCallback));
        mHandler.postDelayed(this::stopScanning, SCAN_PERIOD);
    }

    @SuppressLint({"MissingPermission", "NewApi"})
    public void stopScanning() {
        peripheralTextView.append("Stopped Scanning\n");
        btScanning = false;
        startScanningButton.setVisibility(View.VISIBLE);
        stopScanningButton.setVisibility(View.INVISIBLE);
        AsyncTask.execute(() -> btScanner.stopScan(leScanCallback));
    }

    private void openAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }

    private void startReadingData() {
        if (bluetoothGatt == null || isReading || serviceUUID == null || secondLastUUID == null || lastUUID == null) return;

        isReading = true;
//        readDataButton.setVisibility(View.INVISIBLE);
//        stopReadButton.setVisibility(View.VISIBLE);

        readRunnable = new Runnable() {
            @SuppressLint({"MissingPermission", "NewApi"})
            @Override
            public void run() {
                BluetoothGattService service = bluetoothGatt.getService(serviceUUID);
                if (service != null) {
                    BluetoothGattCharacteristic characteristic = service.getCharacteristic(secondLastUUID);
                    if (characteristic != null) {
                        running = true;
                        bluetoothGatt.readCharacteristic(characteristic);
                    }
                }
                readHandler.postDelayed(this, 1000);
            }
        };
        readHandler.post(readRunnable);
    }

    private void stopReadingData() {
        isReading = false;
        readHandler.removeCallbacks(readRunnable);
//        readDataButton.setVisibility(View.VISIBLE);
//        stopReadButton.setVisibility(View.INVISIBLE);
        peripheralTextView.append("Stopped reading data\n");
    }

    private void writeLog(String value, String uuid) {
        if(value.split(",").length!=2)
            return;

        File logFile = new File(getExternalFilesDir(null), "ble_log.txt");

        try (FileOutputStream fos = new FileOutputStream(logFile, true);
             OutputStreamWriter osw = new OutputStreamWriter(fos)) {
            // Ghi log với định dạng "Thời gian: UUID, Giá trị: Value"
            osw.write(value + "," + uuid + "\n");
            osw.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressLint({"MissingPermission", "NewApi"})
    private void sendDateTimeToDevice() {
        if (bluetoothGatt == null || serviceUUID == null || thirdLastUUID == null) {
            peripheralTextView.append("Error: BluetoothGatt or UUID is null\n");
            return;
        }

        BluetoothGattService service = bluetoothGatt.getService(serviceUUID);
        if (service != null) {
            BluetoothGattCharacteristic characteristic = service.getCharacteristic(thirdLastUUID);
            if (characteristic != null) {
                // Lấy thời gian hiện tại
                String currentDateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

                // Chuyển đổi ngày giờ thành dạng byte và ghi vào characteristic
                characteristic.setValue(currentDateTime.getBytes());

                // Gửi dữ liệu đến thiết bị
                bluetoothGatt.writeCharacteristic(characteristic);

                runOnUiThread(() -> peripheralTextView.append("Sent date and time to device: " + currentDateTime + "\n"));
            } else {
                peripheralTextView.append("Error: Characteristic not found\n");
            }
        } else {
            peripheralTextView.append("Error: Service not found\n");
        }
    }

    private void loadLastValuesFromLog() {
        File logFile = new File(getExternalFilesDir(null), "ble_log.txt");

        if (!logFile.exists()) {
            peripheralTextView.append("Log file does not exist.\n");
            return;
        }

        try (FileInputStream fis = new FileInputStream(logFile);
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader br = new BufferedReader(isr)) {

            String line;
            String lastHeartRate = null;
            String lastSpo2 = null;

            // Đọc từ file log theo từng dòng
            while ((line = br.readLine()) != null) {
                // Tách dữ liệu thành các phần
                String[] parts = line.split(",");

                if (parts.length >= 3) {
                    String timestamp = parts[0];
                    String value = parts[1];
                    String type = parts[2].trim();

                    // Kiểm tra và lưu giá trị cuối cùng cho heart_rate và spo2
                    if ("heart_rate".equals(type)) {
                        lastHeartRate = timestamp + "," + value;
                    } else if ("spo2".equals(type)) {
                        lastSpo2 = timestamp + "," + value;
                    }
                }
            }
            // Gán giá trị cuối cùng cho biến
            pre_secondLastValue = lastHeartRate != null ? lastHeartRate : "null";
            pre_lastValue = lastSpo2 != null ? lastSpo2 : "null";

            Intent intent = new Intent("DATA_UPDATE");
            if (lastHeartRate != null && lastSpo2 != null) {
                intent.putExtra("heart_rate", lastHeartRate);
                intent.putExtra("spo2", lastSpo2);
                sendBroadcast(intent);
            }

            // Hiển thị kết quả
            runOnUiThread(() -> {
                peripheralTextView.append("Last Heart Rate: " + pre_secondLastValue + "\n");
                peripheralTextView.append("Last SPO2: " + pre_lastValue + "\n");
            });

        } catch (IOException e) {
            e.printStackTrace();
            runOnUiThread(() -> peripheralTextView.append("Error reading log file\n"));
        }
    }
}